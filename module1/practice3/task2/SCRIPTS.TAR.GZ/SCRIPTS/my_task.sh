#!/bin/bash

# === 1. Получаем имя скрипта без пути ===
SCRIPT_NAME=$(basename "$0")

# === Проверка имени ===
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

# === Переменные ===
LOG_FILE="report_${SCRIPT_NAME}.log"
CUCKOO_FIFO="/tmp/run/cuckoo.pid"

# === Функция логирования ===
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $1" >> "$LOG_FILE"
}

# === 2. Логируем запуск ===
log "Скрипт запущен"

# === Проверка канала ===
if [[ ! -p "$CUCKOO_FIFO" ]]; then
    log "Ошибка: именованный канал $CUCKOO_FIFO не найден."
    exit 1
fi
echo "DEBUG: Канал существует. Путь: $CUCKOO_FIFO" >&2

# === 3. Запрашиваем время ===
MESSAGE="${SCRIPT_NAME}[$$]: how much time do I have?"
echo "DEBUG: Сформировано сообщение: '$MESSAGE'" >&2

echo "DEBUG: Попытка ЗАПИСИ в канал (echo >)..." >&2
echo "$MESSAGE" > "$CUCKOO_FIFO"
echo "DEBUG: Запись в канал завершена успешно!" >&2

echo "DEBUG: Попытка ЧТЕНИЯ из канала (read <)..." >&2

read -r N < "$CUCKOO_FIFO"
echo "DEBUG: Чтение завершено. Получено значение N=$N" >&2
# === Проверка ответа ===
if ! [[ "$N" =~ ^[0-9]+$ ]]; then
    echo "DEBUG: ОШИБКА! Ответ не является числом: '$N'" >&2
    log "Ошибка: получен некорректный ответ от cuckoo: '$N'"
    exit 1
fi

# === Ожидание ===
echo "DEBUG: Уход в sleep на $N секунд..." >&2
sleep "$N"
echo "DEBUG: Sleep завершен." >&2

# === 4. Логируем завершение ===
log "Скрипт завершился, работал ${N} секунд"
echo "DEBUG: Скрипт успешно завершил работу." >&2

