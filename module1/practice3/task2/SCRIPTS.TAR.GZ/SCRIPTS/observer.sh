#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# Файлы конфигурации и логов
CONF_FILE="observer.conf"
LOG_FILE="observer.log"

# Проверка существования файла конфигурации
if [ ! -f "$CONF_FILE" ]; then
    echo "Ошибка: Файл конфигурации $CONF_FILE не найден."
    exit 1
fi

# Функция для проверки наличия процесса через /proc
is_process_running() {
    local target_script="$1"
    # Перебираем все директории процессов в /proc
    for cmdline_file in /proc/[0-9]*/cmdline; do
        # Проверяем, существует ли файл cmdline
        if [ -f "$cmdline_file" ]; then
            # Читаем cmdline, заменяя нулевые байты (\0) на пробел поиска
            local cmd_content
            cmd_content=$(tr '\0' ' ' < "$cmdline_file" 2>/dev/null)
            # Ищем имя скрипта в строке запуска процесса
            if echo "$cmd_content" | grep -qF "$target_script"; then
                return 0 # Процесс найден
            fi
        fi
    done
    return 1 # Процесс не найден
}

# Читаем файл конфигурации построчно
while IFS= read -r script_path || [ -n "$script_path" ]; do
    # Пропускаем пустые строки и комментарии (начинающиеся с #)
    [[ -z "$script_path" || "$script_path" =~ ^[[:space:]]*# ]] && continue

    # Убираем возможные пробелы в начале и конце строки
    script_path=$(echo "$script_path" | xargs)

    # Проверяем, запущен ли скрипт
    if ! is_process_running "$script_path"; then
        # Если не запущен, проверяем, существует ли сам файл скрипта
        if [ -f "$script_path" ] && [ -x "$script_path" ]; then
            # Запускаем в отключенном от терминала режиме nohup в фоне
            nohup "$script_path" > /dev/null 2>&1 &

            # Записываем информацию о перезапуске в лог
            TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
            echo "[$TIMESTAMP] Скрипт '$script_path' не был запущен. Выполнен перезапуск (PID: $!)." >> "$LOG_FILE"
        else
            TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
            echo "[$TIMESTAMP] Ошибка: Скрипт '$script_path' не найден или не имеет прав на выполнение." >> "$LOG_FILE"
        fi
    fi

done < "$CONF_FILE"
