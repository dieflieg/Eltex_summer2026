#!/bin/bash

# === КОНФИГУРАЦИЯ ===
RUN_DIR="/tmp/run"
FIFO_PATH=""
LOG_FILE="${RUN_DIR}/cuckoo.log"

# === ПАРСИНГ АРГУМЕНТОВ ===
for arg in "$@"; do
    case "$arg" in
        --pishitesuda=*)
            FIFO_PATH="${arg#--pishitesuda=}"
            ;;
        *)
            echo "Неизвестный аргумент: $arg" >&2
            exit 1
            ;;
    esac
done

if [ -z "$FIFO_PATH" ]; then
    echo "Ошибка: обязателен параметр --pishitesuda=<абсолютный путь>" >&2
    exit 1
fi

if [[ "$FIFO_PATH" != /* ]]; then
    echo "Ошибка: --pishitesuda требует абсолютный путь" >&2
    exit 1
fi

# === ФУНКЦИЯ ЛОГИРОВАНИЯ ===
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

# === ОБРАБОТЧИК СИГНАЛА ===
cleanup() {
    log "Shutdown!"
    exec 3>&-           # Закрываем файловый дескриптор
    rm -f "$FIFO_PATH"  # Удаляем именованный канал
    exit 0
}

# Перехватываем SIGTERM (15) и SIGINT (2)
trap cleanup SIGTERM SIGINT

# === ИНИЦИАЛИЗАЦИЯ ===
mkdir -p "$RUN_DIR"

# Удаляем старый FIFO, если остался от предыдущего запуска
[ -p "$FIFO_PATH" ] && rm -f "$FIFO_PATH"

# Создаём именованный канал
mkfifo "$FIFO_PATH"

# Открываем FIFO на чтение И запись (FD 3)
# Это предотвращает EOF при закрытии канала клиентом
exec 3<>"$FIFO_PATH"

# Логируем запуск
log "Startup!"

# === ОСНОВНОЙ ЦИКЛ ===
while IFS= read -r line <&3; do
    # Парсим запрос: NAME[PID]: how much time do I have?
    if [[ "$line" =~ ^([^\[]+)\[([0-9]+)\]:[[:space:]]*how\ much\ time\ do\ I\ have\? ]]; then
        NAME="${BASH_REMATCH[1]}"
        CLIENT_PID="${BASH_REMATCH[2]}"

        # Генерируем случайное число от 2 до 10 включительно
        N=$(( RANDOM % 9 + 2 ))

        # Отправляем ответ обратно в канал
        echo "$N" >&3

        # Логируем обращение и ответ
        log "${NAME}[${CLIENT_PID}] ${N}"
    fi
done
